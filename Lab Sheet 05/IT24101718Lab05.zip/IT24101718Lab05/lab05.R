setwd("C:\\Users\\sadew\\Downloads\\Lab 05-20250828")

data <- read.table("Exercise - Lab 05.txt", header = TRUE, sep = ",")

fix(data)
attach(data)

#1)
Delivery_Times <- data

#2
hist(Delivery_Times$Delivery_Time, breaks = seq(20, 70, length.out = 10), right = FALSE, main = "Histogram of Delivery Times", xlab = "Delivery Time (minutes)", ylab = "Frequency")

#3) The distribution is slightly positively skewed, with most delivery times clustering between 30 and 60 minutes. A primary peak occurs around 37–42 minutes, and a minor secondary peak around 53–59 minutes suggests a possible bimodal tendency.

#4)
hist_obj <- hist(Delivery_Times$Delivery_Time, breaks = seq(20, 70, length.out = 10), right = FALSE, plot = FALSE)
cumfreq <- cumsum(hist_obj$counts)
plot(hist_obj$breaks, c(0, cumfreq), type = "o", main = "Ogive of Delivery Times", xlab = "Delivery Time (minutes)", ylab = "Cumulative Frequency", pch = 19)
