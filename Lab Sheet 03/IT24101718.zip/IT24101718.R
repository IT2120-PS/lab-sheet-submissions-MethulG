setwd("C:/Users/sadew/Downloads/IT24101718")

#1)
student_data<-read.csv("Exercise.csv",header = TRUE)
fix(student_data)

names(student_data)<-c("Age", "Gender", "Accommodation")
attach(student_data)

#2)
summary(student_data$Age)
hist(Age,main = "Histogram for age")

#3)
student_data$Gender<-factor(student_data$Gender,c(1,2), c("Male","Female"))
gender.freq<-table(Gender)
gender.freq

barplot(gender.freq,main="Bat chart for Gender",ylab = "Freequency",xlab = "Gender")
abline(h=0)

#4
student_data$Accommodation<-factor(student_data$Accommodation,c(1,2,3),c("type1","type2","type3"))
boxplot(Age~Accommodation,main="Boxplots for age by gender",xlab="Accomodation",ylab="Age") 
